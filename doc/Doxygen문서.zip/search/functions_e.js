var searchData=
[
  ['updatestripes',['updateStripes',['../html_2dynsections_8js.html#a8f7493ad859d4fbf2523917511ee7177',1,'updateStripes():&#160;dynsections.js'],['../src_2html_2dynsections_8js.html#a8f7493ad859d4fbf2523917511ee7177',1,'updateStripes():&#160;dynsections.js']]],
  ['updateuiformode',['updateUIForMode',['../class_pull_to_refresh_base.html#a269a2a1873303dbc46287b6fff39fcca',1,'PullToRefreshBase']]]
];
