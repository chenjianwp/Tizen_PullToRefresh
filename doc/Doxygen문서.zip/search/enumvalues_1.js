var searchData=
[
  ['manual_5frefreshing',['MANUAL_REFRESHING',['../_enums_8h.html#a5d74787dedbc4e11c1ab15bf487e61f8a261115abbdadd68d9baa72b9dbe06cfe',1,'Enums.h']]]
];
