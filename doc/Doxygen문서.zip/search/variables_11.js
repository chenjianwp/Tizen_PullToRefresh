var searchData=
[
  ['window',['window',['../html_2jquery_8js.html#a04a8a2bbfa9c15500892b8e5033d625b',1,'window():&#160;jquery.js'],['../src_2html_2jquery_8js.html#a04a8a2bbfa9c15500892b8e5033d625b',1,'window():&#160;jquery.js']]]
];
