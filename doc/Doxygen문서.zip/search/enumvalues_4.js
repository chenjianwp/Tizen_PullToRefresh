var searchData=
[
  ['refreshing',['REFRESHING',['../_enums_8h.html#a5d74787dedbc4e11c1ab15bf487e61f8aa6ce367d4a1b5fc676a652e6542d9061',1,'Enums.h']]],
  ['release_5fto_5frefresh',['RELEASE_TO_REFRESH',['../_enums_8h.html#a5d74787dedbc4e11c1ab15bf487e61f8a01149fcd019c94a80a53762a1abe4ce6',1,'Enums.h']]],
  ['reset',['RESET',['../_enums_8h.html#a5d74787dedbc4e11c1ab15bf487e61f8a589b7d94a3d91d145720e2fed0eb3a05',1,'Enums.h']]]
];
