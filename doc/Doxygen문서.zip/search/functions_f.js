var searchData=
[
  ['x',['x',['../html_2jquery_8js.html#a4c3eadaa5164016d2c340d495fc6e55e',1,'x(bx):&#160;jquery.js'],['../src_2html_2jquery_8js.html#a4c3eadaa5164016d2c340d495fc6e55e',1,'x(bx):&#160;jquery.js']]]
];
