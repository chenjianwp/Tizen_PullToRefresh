var searchData=
[
  ['friction',['FRICTION',['../class_pull_to_refresh_base.html#a4f00205c8022035e01c80c2df155a8f9',1,'PullToRefreshBase']]]
];
