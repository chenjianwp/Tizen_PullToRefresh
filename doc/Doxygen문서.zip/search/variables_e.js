var searchData=
[
  ['smooth_5fscroll_5fduration_5fms',['SMOOTH_SCROLL_DURATION_MS',['../class_pull_to_refresh_base.html#abcd4a334a7a176a58be51dd055006fb2',1,'PullToRefreshBase']]],
  ['smooth_5fscroll_5flong_5fduration_5fms',['SMOOTH_SCROLL_LONG_DURATION_MS',['../class_pull_to_refresh_base.html#a8f06e81d1c75fab23d9500c70646e807',1,'PullToRefreshBase']]]
];
